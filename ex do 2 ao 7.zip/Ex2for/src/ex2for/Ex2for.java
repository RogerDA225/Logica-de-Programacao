package ex2for;

import java.util.Scanner;

public class Ex2for {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n, r = 1;
        System.out.println("Digite o enesimo termo: ");
        n = teclado.nextInt();

        for (int i=0; i < n; i++) {
            r *= 2;
            System.out.println(r);
        }

    }

}
