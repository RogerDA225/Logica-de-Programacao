
package ex3for;

import java.util.Scanner;

public class Ex3for {

    public static void main(String[] args) {
        
      Scanner teclado = new Scanner(System.in);
      int votantes, AAA=0, BBB=0, CCC=0, branco=0, voto;
      System.out.println("Insira o numero de votantes: ");
      votantes = teclado.nextInt();
      for (int cont=0; cont < votantes; cont++) {
          System.out.println("vote no candidato desejado");
            voto = teclado.nextInt();
            
            if (voto == 1) {
                AAA++;
            }else if (voto == 2) {
                BBB++;
            }else if (voto == 3) {
                CCC++;
            }else{
                branco++;
            }
        }  
        
        System.out.println("votos no candidato AAA: "+ AAA);
        System.out.println("votos no candidato BBB: "+ BBB);
        System.out.println("votos no candidato CCC: "+ CCC);
        System.out.println("votos em branco: "+ branco);
        
        if (AAA > BBB && AAA > CCC) {
            System.out.println("AAA venceu");
        }else if (CCC > BBB && AAA < CCC) {
            System.out.println("CCC venceu");
        }else if (AAA < BBB && BBB > CCC) {
            System.out.println("BBB venceu");
        }else{
            if (AAA==BBB&&AAA==CCC) {
                System.out.println("todos empataram");
            }else if (AAA == BBB) {
                System.out.println("AAA e BBB empataram");
            }else if (AAA == CCC) {
                System.out.println("AAA e CCC empataram");
            }else{
                System.out.println("BBB e CCC empataram");
            }
      }
    }
    
}
