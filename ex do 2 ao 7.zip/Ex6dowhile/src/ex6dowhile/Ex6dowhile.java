

package ex6dowhile;

import java.util.Scanner;

public class Ex6dowhile {

    public static void main(String[] args) {
        
         Scanner teclado = new Scanner(System.in);
        int numero, divisor=2;
        boolean Nprimo = false;
        System.out.println("Digite o numero: ");
        numero = teclado.nextInt();
        do {
            if (numero % divisor == 0) {
                Nprimo = true;
                divisor = numero;
            }
            divisor++;
        } while (divisor < numero);
        
        if (!Nprimo) {
            System.out.println("e primo");
        }else{
            System.out.println("nao e primo");
        }
    }
    
}
