package ex5for;

import java.util.Scanner;

public class Ex5for {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int ultimo=1, penultimo=-1, proximo, n;
        System.out.println("Digite o enesimo termo: ");
        n = teclado.nextInt();
        for (int cont=0; cont < n; cont++) {
            proximo = ultimo + penultimo;
            System.out.println(proximo);
            penultimo = ultimo;
            ultimo = proximo;
            
        }
    }
    
}
