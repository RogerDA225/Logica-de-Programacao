
package ex6for;

import java.util.Scanner;

public class Ex6for {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numero;
        boolean Nprimo = false;
        System.out.println("Digite o numero: ");
        numero = teclado.nextInt();
        for (int divisor=2; divisor < numero; divisor++) {
            if (numero % divisor == 0) {
                Nprimo = true;
                divisor = numero;
            }
            
        }
        
        if (!Nprimo) {
            System.out.println("e primo");
        }else{
            System.out.println("nao e primo");
        }
    }
    
}
