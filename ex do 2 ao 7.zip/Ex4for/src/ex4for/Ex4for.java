
package ex4for;

import java.util.Scanner;

public class Ex4for {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int  n, r=1 ;
        System.out.println("Digite o numero para calcular fatorial: ");
        n = teclado.nextInt();
        
        for(int cont=1; n>=cont; cont++) {            
            r *= cont;
            
        }
        System.out.println("fatorial e "+ r);
    }
    
}
