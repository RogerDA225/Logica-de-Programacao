
package ex2while;

import java.util.Scanner;

public class Ex2while {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int n, i=0, r=1;
        System.out.println("Digite o enesimo termo: ");
        n = teclado.nextInt();
        
        while (i < n) {
           r *= 2;
           System.out.println(r);
           i++;
        }
    }
    
}
