
package ex5dowhile;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Ex5doWhile {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
        int cont=0,ultimo=1, penultimo=-1, proximo, n;
        System.out.println("Digite o enesimo termo: ");
        n = teclado.nextInt();
        do {
            proximo = ultimo + penultimo;
            System.out.println(proximo);
            penultimo = ultimo;
            ultimo = proximo;
            cont++;
        } while (cont < n);
    }
    
}
