
package ex4while;

import java.util.Scanner;

public class Ex4while {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int cont=1, n, r=1 ;
        System.out.println("Digite o numero para calcular fatorial: ");
        n = teclado.nextInt();
        
        while (n>=cont) {            
            r *= cont;
            
            cont++;
        }
        System.out.println("fatorial e "+ r);
    }
    
}
