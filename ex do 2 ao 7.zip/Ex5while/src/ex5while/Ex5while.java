
package ex5while;

import java.util.Scanner;

public class Ex5while {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        int cont=0,ultimo=1, penultimo=-1, proximo, n;
        System.out.println("Digite o enesimo termo: ");
        n = teclado.nextInt();
        while (cont < n) {
            proximo = ultimo + penultimo;
            System.out.println(proximo);
            penultimo = ultimo;
            ultimo = proximo;
            cont++;
        }
        
    }
    
}
