
package ex7while;

import java.util.Scanner;

public class Ex7while {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int n = 2, cont=1, f = 1, contf;
        double E=1;
        System.out.println("Digite o numero");
        n = teclado.nextInt();
       
        
        while (cont<=n) {
            contf = cont;
            while (contf<=n) {            
                f *= contf;
                contf++;  
            }
            
            E += cont*10/f;
            f = 1;
            cont++;
        }
        System.out.println(E);
        
        
    }
    
}
