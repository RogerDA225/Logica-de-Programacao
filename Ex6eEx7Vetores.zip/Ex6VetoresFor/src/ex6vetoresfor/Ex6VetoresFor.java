package ex6vetoresfor;

import java.util.Scanner;

public class Ex6VetoresFor {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numero_automoveis;
        double combustivel;
        System.out.println("Digite o numero de automoveis: ");
        numero_automoveis = teclado.nextInt();
        System.out.println("Digite o valor do combustivel: ");
        combustivel = teclado.nextDouble();
        teclado.nextLine();
        String vet_modelo[] = new String[numero_automoveis];
        double vet_consumo[] = new double[numero_automoveis];
        String mais_economico = null, menos_economico = null;
        double valor_mais_economico = 0, valor_menos_economico = 1000, reais_corrida;
        
        for (int i = 0; i < numero_automoveis; i++) {
            System.out.println("Digite o modelo do " + (i+1) + "o automovel: ");
            vet_modelo[i] = teclado.nextLine();
            teclado.nextLine();
            System.out.println("Digite o consumo medio do " + (i+1) + "o automovel: ");
            vet_consumo[i] = teclado.nextDouble();
            teclado.nextLine();
        }
        
        for (int i = 0; i < numero_automoveis; i++) {
            if (vet_consumo[i] > valor_mais_economico) {
                valor_mais_economico = vet_consumo[i];
                mais_economico = vet_modelo[i];
            }
        }
        System.out.println("O mais economico: " + mais_economico);
        
        for (int i = 0; i < numero_automoveis; i++) {
            if (vet_consumo[i] < valor_menos_economico) {
                valor_menos_economico = vet_consumo[i];
                menos_economico = vet_modelo[i];
            }
        }
        System.out.println("O menos economico: " + menos_economico);
        
        for (int i = 0; i < numero_automoveis; i++) {
            reais_corrida = (780.0 / vet_consumo[i]) * combustivel;
            System.out.println("O " + vet_modelo[i] + " vai gastar RS" + reais_corrida + " para percorrer 780km");
        }
    }

}
