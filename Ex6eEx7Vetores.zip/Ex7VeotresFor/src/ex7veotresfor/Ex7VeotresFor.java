
package ex7veotresfor;

import java.util.Scanner;

public class Ex7VeotresFor {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 5;
        String vet_nomes[] = new String [tamanho];
        double vet_salario[] = new double [tamanho];
        int vet_tempo[] = new int [tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome do funcionario: ");
            vet_nomes[i] = teclado.nextLine();
            System.out.println("Informe o salario do funcionario: ");
            vet_salario[i] = teclado.nextDouble();
            System.out.println("Informe o tempo de servico do funcionario: ");
            vet_tempo[i] = teclado.nextInt();
            teclado.nextLine();
        }
        System.out.println("Os que nao receberam aumento: "
                + "");
        for (int i = 0; i < tamanho; i++) {
            if (vet_salario[i] >= 1940.0 && vet_tempo[i] <= 5) {
                System.out.println(vet_nomes[i]);
            }
        }
        
        System.out.println("Os que receberam aumento: "
                + "");
        for (int i = 0; i < tamanho; i++) {
            if (vet_salario[i] < 1940.0 && vet_tempo[i] > 5) {
                System.out.println(vet_nomes[i] + " novo salario: " + (vet_salario[i] * 1.35) + " reais");
            } else if (vet_salario[i] >= 1940.0 && vet_tempo[i] > 5) {
                System.out.println(vet_nomes[i] + " novo salario: " + (vet_salario[i] * 1.25) + " reais");
            } else if (vet_salario[i] < 1940.0 && vet_tempo[i] < 5) {
                System.out.println(vet_nomes[i] + " novo salario: " + (vet_salario[i] * 1.15) + " reais");
            }
        }
    }
    
}
