
package ex03matrizes;

import java.util.Scanner;

public class Ex03Matrizes {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double matriz_numeros[][] = new double [2][2];
        double matriz_resultante[][] = new double [2][2];
        double maior;
        
        for (int linha = 0; linha < 2; linha++) {
            for (int coluna = 0; coluna < 2; coluna++) {
                System.out.println("Digite o numero da " + (linha+1) + "a linha da " + (coluna+1) + "a coluna");
                matriz_numeros[linha][coluna] = teclado.nextDouble();
            }
        }
        
        maior = matriz_numeros[0][0];
        
        for (int linha = 0; linha < 2; linha++) {
            for (int coluna = 0; coluna < 2; coluna++) {
                if (matriz_numeros[linha][coluna] > maior) {
                    maior = matriz_numeros[linha][coluna];
                }
            }
        }
        
        for (int linha = 0; linha < 2; linha++) {
            for (int coluna = 0; coluna < 2; coluna++) {
                matriz_resultante[linha][coluna] = matriz_numeros[linha][coluna] * maior;
            }
        }
        
        for (int linha = 0; linha < 2; linha++) {
            System.out.println(" ");
            for (int coluna = 0; coluna < 2; coluna++) {
                System.out.print(matriz_resultante[linha][coluna] + " ");
            }
        }
    }
    
}
