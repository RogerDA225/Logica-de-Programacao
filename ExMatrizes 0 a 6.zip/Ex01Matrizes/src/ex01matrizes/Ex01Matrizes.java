
package ex01matrizes;

import java.util.Scanner;

public class Ex01Matrizes {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int matriz_numeros[][] = new int [5][5];
        for (int linha = 0; linha < 5; linha++) {
            for (int coluna = 0; coluna < 5; coluna++) {
                System.out.println("Informe o numero da " + (linha+1) + "a linha da " + (coluna+1) + "a coluna: ");
                matriz_numeros[linha][coluna] = teclado.nextInt();
            }
        }
        
        for (int linha = 0; linha < 5; linha++) {
            System.out.println(" ");
            for (int coluna = 0; coluna < 5; coluna++) {
                System.out.print(matriz_numeros[linha][coluna] + " ");
            }
        }
    }
    
}
