
package ex02matrizes;

import java.util.Scanner;

public class Ex02Matrizes {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int matriz_numeros[][] = new int [3][3];
        int menor;
        for (int linha = 0; linha < 3; linha++) {
            for (int coluna = 0; coluna < 3; coluna++) {
                System.out.println("Informe o numero da " + (linha+1) + "a linha da " + (coluna+1) + "a coluna: ");
                matriz_numeros[linha][coluna] = teclado.nextInt();
            }
        }
        menor = matriz_numeros[0][0];
        
        for (int linha = 0; linha < 3; linha++) {
            for (int coluna = 0; coluna < 3; coluna++) {
                if (matriz_numeros[linha][coluna] < menor) {
                    menor = matriz_numeros[linha][coluna];
                }
            }
        }
        
        System.out.println("O menor elemento da matriz eh: " + menor);
    }
    
}
