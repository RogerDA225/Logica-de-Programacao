
package ex05matrizes;

import java.util.Scanner;

public class Ex05Matrizes {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       String vet_lojas[] = new String [4];
       String vet_produtos[] = new String [6];
       double matriz_precos[][] = new double [4][6];
       
        for (int i = 0; i < 4; i++) {
            System.out.println("Digite a " + (i+1) + "a loja: ");
            vet_lojas[i] = teclado.nextLine();
        }
        for (int i = 0; i < 6; i++) {
            System.out.println("Digite o " + (i+1) + "o produto de cada loja: ");
            vet_produtos[i] = teclado.nextLine();
        }
        
        for (int loja = 0; loja < 4; loja++) {
            for (int produto = 0; produto < 6; produto++) {
                System.out.println("Digite o preco do " + (produto+1) + "o produto da " + (loja+1) + "a loja: ");
                matriz_precos[loja][produto] = teclado.nextDouble();
  
            } 
        }
        
        for (int loja = 0; loja < 4; loja++) {
            System.out.println(""
                    + "");
            System.out.println(vet_lojas[loja] + ": ");
            for (int produto = 0; produto < 6; produto++) {
                if (matriz_precos[loja][produto] > 50.0) {
                    System.out.print(vet_produtos[produto] + " " + matriz_precos[loja][produto] + " ");
                }
            }
        }
    }
    
}
