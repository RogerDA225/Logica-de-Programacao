
package ex06matrizes;

import java.util.Scanner;

public class Ex06Matrizes {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int matriz[][] = new int [15][5];
       int numeroAleatorio = (int) (Math.random() * 50);
       int cont_numero = 0;
       
        for (int linha = 0; linha < 15; linha++) {
            for (int coluna = 0; coluna < 5; coluna++) {
               matriz[linha][coluna] = numeroAleatorio;
               numeroAleatorio = (int) (Math.random() * 50);
            }
        }
        
        for (int numero = 0; numero <= 50; numero++) {
            for (int linha = 0; linha < 15; linha++) {
                for (int coluna = 0; coluna < 5; coluna++) {
                    if (matriz[linha][coluna] == numero) {
                        cont_numero++;
                    }
                }
            }
            System.out.println(numero + " se repete " + cont_numero + " vezes");
            cont_numero = 0;
        }
        
    }
    
}
