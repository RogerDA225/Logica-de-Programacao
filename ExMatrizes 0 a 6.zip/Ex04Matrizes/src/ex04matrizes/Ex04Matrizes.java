
package ex04matrizes;

import java.util.Scanner;

public class Ex04Matrizes {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       String vet_alunos[] = new String [6];
       double acumulador = 0;
       double vet_medias[] = new double [6];
       double matriz_notas[][] = new double [6][3];
       
        for (int i = 0; i < 6; i++) {
            System.out.println("Digite o nome do " + (i+1) + "o aluno: ");
            vet_alunos[i] = teclado.nextLine();
        }
        
        for (int aluno = 0; aluno < 6; aluno++) {
            for (int nota = 0; nota < 3; nota++) {
                System.out.println("Digite a " + (nota+1) + "a nota do " + (aluno+1) + "o aluno: ");
                matriz_notas[aluno][nota] = teclado.nextDouble();
                acumulador += matriz_notas[aluno][nota];
            }
           vet_medias[aluno] = acumulador / 3.0;
           acumulador = 0;
        }
        
        for (int aluno = 0; aluno < 6; aluno++) {
            if (vet_medias[aluno] >= 6.0) {
                System.out.println(vet_alunos[aluno] + " Media: " + vet_medias[aluno] + " Aprovado");
            } else {
                System.out.println(vet_alunos[aluno] + " Media: " + vet_medias[aluno] + " Reprovado");
            }   
        }
    }
    
}
