
package ex4vetoreswhile;

import java.util.Scanner;

public class Ex4VetoresWhile {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 5, tamanho_mesclado = 10, i = 0;
        String vet_animais[] = new String [tamanho];
        String vet_frutas[] = new String [tamanho];
        String vet_mesclado[] = new String [tamanho_mesclado];
        while (i < tamanho) {
            System.out.println("Digite o " + (i+1) + "o animal: ");
            vet_animais[i] = teclado.nextLine();
            i++;
        }
        i = 0;
        while (i < tamanho) {
            System.out.println("Digite a " + (i+1) + "a fruta: ");
            vet_frutas[i] = teclado.nextLine();
            i++;
        }
        i = 0;
        while (i < tamanho_mesclado) {
            if (i % 2 == 0) {
                vet_mesclado[i] = vet_animais[(i / 2)];
            } else {
                vet_mesclado[i] = vet_frutas[(i - 1) / 2];
            }
            i++;
        }
        i = 0;
        System.out.println(""
                + "");
        while (i < tamanho_mesclado) {
            System.out.println(vet_mesclado[i]);
            i++;
        }
    }
}
