
package ex4vetoresfor;

import java.util.Scanner;

public class Ex4VetoresFor {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 5, tamanho_mesclado = 10;
        String vet_animais[] = new String [tamanho];
        String vet_frutas[] = new String [tamanho];
        String vet_mesclado[] = new String [tamanho_mesclado];
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome do " + (i+1) +  "o animal: ");
            vet_animais[i] = teclado.nextLine();
        }
        for (int i = 0; i < tamanho; i++) {
             System.out.println("Digite o nome da " + (i+1) + "a fruta: ");
            vet_frutas[i] = teclado.nextLine();
        }
        for (int i = 0; i < tamanho_mesclado; i++) {
            if (i % 2 == 0) {
                vet_mesclado[i] = vet_animais[(i / 2)];
            } else {
                vet_mesclado[i] = vet_frutas[(i - 1) / 2];
            }
        }
        System.out.println(""
                + "");
        for (int i = 0; i < tamanho_mesclado; i++) {
            System.out.println(vet_mesclado[i]);
        }
    }
    
}
