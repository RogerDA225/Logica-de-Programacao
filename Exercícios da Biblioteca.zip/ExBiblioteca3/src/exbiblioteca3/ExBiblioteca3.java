package exbiblioteca3;

import java.util.Scanner;

public class ExBiblioteca3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho_n;
        System.out.println("Digite o tamanho do vetor: ");
        tamanho_n = teclado.nextInt();
        double vetor[] = new double [tamanho_n];
        double soma = 0;
        
        for (int i = 0; i < tamanho_n; i++) {
            System.out.println("Digite o " + (i+1) + "o valor: ");
            vetor[i] = teclado.nextDouble();
        }
        
        for (int i = 0; i < tamanho_n; i++) {
            if (i % 2 == 0) {
                soma += vetor[i];
            }
        }
        
        System.out.println("A soma de todos os elementos de indice par do vetor eh: " + soma);
    }

}
