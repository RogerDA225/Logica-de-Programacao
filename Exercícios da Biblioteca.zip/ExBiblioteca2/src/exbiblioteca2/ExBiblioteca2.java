
package exbiblioteca2;

import java.util.Scanner;

public class ExBiblioteca2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n_elementos, maior_diferenca = 0;
        System.out.println("Digite o tamanho do vetor A: ");
        n_elementos = teclado.nextInt();
        int vetorA[] = new int [n_elementos];
        int vet_dierencas[] = new int [n_elementos - 1];
        
        for (int i = 0; i < n_elementos; i++) {
            System.out.println("Informe o " + (i+1) + "o elemento: ");
            vetorA[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < (n_elementos - 1); i++) {
            vet_dierencas[i] = vetorA[(i+1)] - vetorA[i];
        }
        
        for (int i = 0; i < (n_elementos - 1); i++) {
            if (vet_dierencas[i] > maior_diferenca) {
                maior_diferenca = vet_dierencas[i];
            }
        }
        
        System.out.println("A maior difernca entre os elementos consecutivos do vetor A eh: " + maior_diferenca);
    }
    
}
