
package exerciciobiblioteca;

import java.util.Scanner;

public class ExercicioBiblioteca {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho_n, a, b, cont_intervalo = 0;
        System.out.println("Digite o tamanho do vetor: ");
        tamanho_n = teclado.nextInt();
        int vetor[] = new int [tamanho_n];
        System.out.println("Digite o valor de a: ");
        a = teclado.nextInt();
        System.out.println("Digite o valor de b: ");
        b = teclado.nextInt();
        
        for (int i = 0; i < tamanho_n; i++) {
            System.out.println("Digite o " + (i+1) + "o valor do vetor: ");
            vetor[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < tamanho_n; i++) {
            if (vetor[i] >= a && vetor[i] <= b || vetor[i] >= b && vetor[i] <= a) {
                cont_intervalo++;
            }
        }
        
        System.out.println("A quantidade de elementos do vetor que estao no intervalo fechado [a, b] eh: " + cont_intervalo);
    }
    
}
